# First_Responsive_Website

Developed a responsive web page using HTML5 and CSS3. Reponsive for three devices i.e., mobile, tablet and laptop.

You can select any business/group/institution of your liking.

The page contains the following elements ...

1. Header with a nav bar
2. 1 column hero unit (Hero section to be full width, edge to edge)
3. 3 column section
4. A section which contains 2 vertical columns. First vertical column should contain a form. The second column  should be divided in to 3 rows 
5. A footer. with social media links and site links. (Not functional) - using font awesome icons http://fontawesome.io/icons/

Additional Features: 
1. Used google font for displaying text
2. Fixed header with page scroll beneath the header



 


